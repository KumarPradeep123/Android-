package com.example.lenovo.smssenderwithpermission;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private final int SEND_SMS_PERMISSION = 1;
    EditText txtNo, txtMsg;
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNo = (EditText) findViewById(R.id.editText);
        txtMsg = (EditText) findViewById(R.id.editText2);
        txt = (TextView) findViewById(R.id.textView4);
    }

    public void sendMessage(View view) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String sendTo = ("" + txtNo.getText());
            String myMessage = ("" + txtMsg.getText());
            smsManager.sendTextMessage(sendTo, null, myMessage, null, null);
            setTitle("Sent");
        } catch (Exception ex) {
            setTitle(ex.getMessage());

        }
    }

    public void getPermission(View view) {
        setTitle("Clicked");
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                // Show an explanation if permission has been
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                    txt.setText("This App needs to send SMS");
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION);
                } else {
                    // No explanation needed, we can request the permission.
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION);
                }
            } else
                setTitle("Has SMS Sending Permission");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        switch (requestCode) {
            case SEND_SMS_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setTitle("Permission Given");
                } else {
                    setTitle("Permission Not Given");
                    return;
                }
            }
        }
    }
}
