package com.example.lenovo.smstracking;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtNo, txtMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNo = (EditText) findViewById(R.id.editText);
        txtMsg = (EditText) findViewById(R.id.editText2);

    }

    public void sendMessage(View view) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String sendTo = ("" + txtNo.getText());
            String myMessage = ("" + txtMsg.getText());
            smsManager.sendTextMessage(sendTo, null, myMessage, null, null);
            setTitle("Sent");
            registerReceiver(new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String resultText = "undefined problem";

                    switch (getResultCode()) {
                        case Activity.RESULT_OK:
                            resultText = "Transmission successful";
                            break;
                        case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                            resultText = "Transmission failed";
                            break;
                        case SmsManager.RESULT_ERROR_RADIO_OFF:
                            resultText = "Transmission failed : Radio is off";
                            break;
                        case SmsManager.RESULT_ERROR_NULL_PDU:
                            resultText = "Transmission failed : No PDU specified";
                            break;
                        case SmsManager.RESULT_ERROR_NO_SERVICE:
                            resultText = "Transmission failed : No service";
                            break;
                    }
                    Toast.makeText(context, resultText, Toast.LENGTH_LONG).show();
                }
            }, new IntentFilter(SENT_SMS_ACTION));
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    String SENT_SMS_ACTION = "com.paad.smssnippets.SENT_SMS_ACTION";
    String DELIVERED_SMS_ACTION = "com.paad.smssnippets.DELIVERED_SMS_ACTION";

}