package com.example.pradeepkumar.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by PRADEEP KUMAR on 13-01-2018.
 */

public class NotifyBootReceiver extends BroadcastReceiver {
    NotifyAlarmReceiver alarm = new NotifyAlarmReceiver();
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("android.intent.equals.BOOT_COMPLETED"))
        {
            alarm.setAlarm(context);
        }

    }
}
