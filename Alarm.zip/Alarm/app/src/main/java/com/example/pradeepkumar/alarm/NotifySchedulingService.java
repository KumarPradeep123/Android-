package com.example.pradeepkumar.alarm;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;

/**
 * Created by PRADEEP KUMAR on 13-01-2018.
 */

public class NotifySchedulingService extends IntentService {
    public NotifySchedulingService() {
        super("SchedulingService");
    }
    @Override
    protected void onHandleIntent(Intent intent) {
        Context context = getApplicationContext();
        try
        {

            Utilities.SendNotification("Alarm", context);
        }
        catch (Exception ex)
        {
            System.out.println(ex);
            Utilities.SendNotification("" + ex, context);
        }
        NotifyAlarmReceiver.completeWakefulIntent(intent);
    }
}