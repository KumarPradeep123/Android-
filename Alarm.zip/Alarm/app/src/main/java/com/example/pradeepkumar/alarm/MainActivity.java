package com.example.pradeepkumar.alarm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotifyAlarmReceiver alarm = new NotifyAlarmReceiver();
        alarm.setAlarm(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }


    public void setAlarm(View view) {
        try {
            setTitle("ALarm");
            Utilities.SendNotification("Alarm", this);

        } catch (Exception ex) {
            setTitle(ex.getMessage());

        }
    }
}
