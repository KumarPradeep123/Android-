package com.example.pradeepkumar.netaccessdemo1;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    EditText TxtUrl, TxtData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TxtUrl=(EditText)findViewById(R.id.editText);
        TxtData=(EditText)findViewById(R.id.editText2);
    }
    public void download(View v){
        //setTitle("Downloading...");
        Toast.makeText(this,"Just wait...Downloading",Toast.LENGTH_LONG).show();
        Downloader downloader=new Downloader();
        downloader.execute();
    }
    class Downloader extends AsyncTask{

        @Override
        protected Object doInBackground(Object[] objects) {
            try {
                URL url = new URL("http://" + TxtUrl.getText());
                URLConnection connection = url.openConnection();
                Scanner scanner = new Scanner(connection.getInputStream());
                String str = "";
                while (scanner.hasNextLine())
                    str = str + scanner.nextLine() + "\n";
                return str;
            } catch (Exception ex) {
                return ex;
            }
        }

        @Override
        protected void onPostExecute(Object o) {
            try{
                if(o instanceof Exception)
                    throw (Exception) o;

            }catch (Exception ex){
                TxtData.setText(ex.getMessage());
            }
        }
    }
}
