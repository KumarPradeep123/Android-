package com.example.pradeepkumar.netaccessdemo3savedata;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by PRADEEP KUMAR on 05-12-2017.
 */

public class MyAdapter implements ListAdapter {
    private LayoutInflater inflater;
    private Context context;
    private List<Book> books;
    public MyAdapter(Context context, List<Book> books){
        this.context=context;
        this.books=books;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return false;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {
        return books.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View rowView = inflater.inflate(R.layout.layout, null);
        TextView txtName=(TextView)rowView.findViewById(R.id.txtName);
        TextView txtAuthor=(TextView)rowView.findViewById(R.id.txtAuthor);
        TextView txtPrice=(TextView)rowView.findViewById(R.id.txtPrice);
        Book book=books.get(i);
        txtName.setText(book.getName());
        txtAuthor.setText(book.getAuthor());
        txtPrice.setText(book.getPrice());
        return rowView;
    }

    @Override
    public int getItemViewType(int i) {
        return 1;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
