package com.example.pradeepkumar.netaccessdemo3savedata;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    EditText txtUrl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.lv);
        txtUrl=(EditText)findViewById(R.id.editText);
    }
    public void download(View view){
        setTitle("downloading");
        Downloader downloader=new Downloader();
        downloader.execute();
    }
    class Downloader extends AsyncTask
    {

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                URL url=new URL("http://" + txtUrl.getText());
               // URL url=new URL("http://pradeep.softwareforyou.in/data.html");
                URLConnection connection= url.openConnection();
                Scanner scanner=new Scanner(connection.getInputStream());
                String str="";
                while (scanner.hasNextLine())
                    str=str + scanner.nextLine();
                return str;
            }
            catch (Exception ex)
            {
                return ex;
            }


        }
        @Override
        protected void onPostExecute(Object o)
        {
            try
            {
                if(o instanceof Exception)
                    throw (Exception)o;
                JSONObject jsonObject=new JSONObject("" + o);
                JSONArray jsonArray=jsonObject.getJSONArray("books");
                int length=jsonArray.length();
                List<Book> books=new ArrayList<>();
                for(int i=0;i<=length-1;i++)
                {
                    JSONObject object=(JSONObject)  jsonArray.get(i);
                    String name=object.getString("name");
                    String author=object.getString("author");
                    String price=object.getString("price");
                    Book book=new Book(name,author,price);
                    books.add(book);
                }
                MyAdapter adapter = new MyAdapter(MainActivity.this,books);
                lv.setAdapter(adapter);
                setTitle("" + length);

            }
            catch (Exception ex)
            {
                setTitle (ex.getMessage());
            }
        }
    }
}
