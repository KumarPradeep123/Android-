package com.example.pradeepkumar.netaccessdemo3savedata;

/**
 * Created by PRADEEP KUMAR on 06-12-2017.
 */

public class Book {
    String name;
    String author;
    String price;

    public Book(String name, String author, String price) {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    public String getName() {return name;}

    public String getAuthor() {
        return author;
    }

    public String getPrice() {
        return price;
    }
}
