package com.example.lenovo.smsreceiverdemo;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    EditText nmbr, msg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.textView);
        nmbr=(EditText) findViewById(R.id.editText);
        msg=(EditText) findViewById(R.id.editText2);
    }

    public void send(View view) {
        try {
            setTitle("Sent");
            String Number = nmbr.getText().toString();
            String Message = msg.getText().toString();
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(Number, null, Message, null, null);
            Utilities.sendNotification(this, "Sent");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
    public void next(View view) {
        try {
            Intent intent = new Intent(this, NextActivity.class);
            startActivity(intent);
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            String query = "create table SmsInfo(Number text primary key, Message text)";
            ContentValues values = new ContentValues();
            values.put("Number", "" + nmbr.getText());
            values.put("Sms", "" + msg.getText());
            db.execSQL(query);
            db.insert("SmsInfo", null, values);
        }catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }




}

