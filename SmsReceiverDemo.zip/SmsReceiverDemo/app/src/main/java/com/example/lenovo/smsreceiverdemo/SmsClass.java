package com.example.lenovo.smsreceiverdemo;

/**
 * Created by LENOVO on 11/19/2017.
 */

public class SmsClass
{
    String Number,Sms;

    public SmsClass(Object Number,Object Sms) {
        this.Number ="" + Number;
        this.Sms="" + Sms;
    }

    @Override
    public String toString() {
        return "SmsClass{" +
                "Number='" + Number + '\'' +
                ", Sms='" + Sms + '\'' +
                '}';
    }
}