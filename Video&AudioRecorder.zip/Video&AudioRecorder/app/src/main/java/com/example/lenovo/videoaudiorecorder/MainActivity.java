package com.example.lenovo.videoaudiorecorder;

import android.content.Intent;
import android.graphics.Camera;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    VideoView videoView;
    MediaRecorder mediaRecorder;
    android.hardware.Camera camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        videoView=(VideoView)findViewById(R.id.videoView);
    }
    public void video(View view){
        try{
            //Intent intent=new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            //startActivityForResult(intent, RECORD_VIDEO);
            camera= android.hardware.Camera.open();
            camera.release();
            camera.unlock();
            mediaRecorder.setCamera(camera);
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
            mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
            CamcorderProfile profile=null;
            if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_1080P))
                profile = CamcorderProfile.get(CamcorderProfile.QUALITY_1080P);
            else if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_720P))
                profile = CamcorderProfile.get(CamcorderProfile.QUALITY_720P);
            else if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_480P))
                profile = CamcorderProfile.get(CamcorderProfile.QUALITY_480P);
            else if (CamcorderProfile.hasProfile(CamcorderProfile.QUALITY_HIGH))
                profile = CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH);

            if (profile != null)
                mediaRecorder.setProfile(profile);
            mediaRecorder.setOutputFile("/sdcard/myvideorecording.mp4");
            mediaRecorder.prepare();

        }catch (Exception ex){
            setTitle(ex.getMessage());
        }
    }
}
