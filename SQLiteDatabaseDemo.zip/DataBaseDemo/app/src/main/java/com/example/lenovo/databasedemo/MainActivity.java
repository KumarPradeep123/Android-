package com.example.lenovo.databasedemo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = (EditText) findViewById(R.id.editText);
        e2 = (EditText) findViewById(R.id.editText2);
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            String query = "create table student(rollno text primary key,name text)";
            db.execSQL(query);
            setTitle("Created");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void insert(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("rollno", "" + e1.getText());
            values.put("name", "" + e2.getText());
            db.insert("student", null, values);
            setTitle("Inserted");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void update(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values=new ContentValues();
            values.put("name","" + e2.getText());
            db.update("student",values,"rollno=?",new String[]{"" + e1.getText()});
            setTitle("Updated");
        }
        catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void select(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "student", new String[]{"name"}, "rollno=?", new String[]{"" + e1.getText()}, null, null, null, null);
            if (cursor.moveToFirst()) {
                setTitle("Selected");
                e2.setText("" + cursor.getString(0));
                return;
            } else {
                e2.setText("Not found");
            }
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void delete(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            db.delete("student","rollno=?",new String[]{"" + e1.getText()});
            setTitle("Deleted");
        }
        catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}
