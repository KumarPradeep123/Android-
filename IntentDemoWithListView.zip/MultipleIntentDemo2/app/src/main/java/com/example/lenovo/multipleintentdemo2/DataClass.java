package com.example.lenovo.multipleintentdemo2;

/**
 * Created by LENOVO on 11/3/2017.
 */

public class DataClass
{
    String data1,data2;

    public DataClass(Object data1,Object data2) {
        this.data1 ="" + data1;
        this.data2="" + data2;
    }

    @Override
    public String toString() {
        return "DataClass{" +
                "data1='" + data1 + '\'' +
                ", data2='" + data2 + '\'' +
                '}';
    }
}
