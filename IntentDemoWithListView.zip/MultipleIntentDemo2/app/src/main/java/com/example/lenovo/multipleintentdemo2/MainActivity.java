package com.example.lenovo.multipleintentdemo2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText txtData1, txtData2;
    final int reqcode = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtData1 = (EditText) findViewById(R.id.editText);
        txtData2 = (EditText) findViewById(R.id.editText2);
    }

    public void next(View view) {
        setTitle("Clicked");
        Intent intent = new Intent(this, NextActivity.class);
        //intent.putExtra("data", "" + txtData.getText());
        startActivityForResult(intent, reqcode);
    }

    public void create(View view) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            String query = "create table DataInfo(data1 text primary key, data2 text)";
            db.execSQL(query);
            setTitle("Created");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
    public void insert(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("data1", "" + txtData1.getText());
            values.put("data2", "" + txtData2.getText());
            long n= db.insert("DataInfo", null, values);
            setTitle("Inserted " + n) ;
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}

