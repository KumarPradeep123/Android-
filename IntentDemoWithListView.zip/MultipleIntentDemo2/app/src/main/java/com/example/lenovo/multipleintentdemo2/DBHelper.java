package com.example.lenovo.multipleintentdemo2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

/**
 * Created by LENOVO on 11/2/2017.
 */

public class DBHelper extends SQLiteOpenHelper {
    Context context;

    public DBHelper(Context context) {super(context, "test", null, 1);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    //*******************************************************************************************
    public Vector<DataClass> search() {
        Vector<DataClass> vector=new Vector<>();
        try {
            vector.add(new DataClass("..",".."));
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "DataInfo", new String[]{"data1", "data2"}, null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                vector.add(new DataClass(cursor.getString(0),cursor.getString(1)));
            }
            return vector;
        } catch (Exception ex) {
            vector.add(new DataClass("Error", ex.getMessage()));
            return vector;
        }
    }
    //****************************************************************************************

}
