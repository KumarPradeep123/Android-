package com.example.lenovo.multipleintentdemo2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.Vector;

public class NextActivity extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        try {
            lv = (ListView) findViewById(R.id.lv);
            DBHelper helper = new DBHelper(this);
            Vector<DataClass> vector = helper.search();
            MyAdapter adapter = new MyAdapter(this, vector);
            lv.setAdapter(adapter);
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}
