package com.example.pradeepkumar.recyclerview.model;

/**
 * Created by PRADEEP KUMAR on 17-01-2018.
 */

public class Item {
    private  int rollNo;
    private String name;

        public Item(int rollNo, String name) {
            this.rollNo = rollNo;
            this.name = name;
        }
        public int getRollNo() {
            return rollNo;
        }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
            return name;
        }
}