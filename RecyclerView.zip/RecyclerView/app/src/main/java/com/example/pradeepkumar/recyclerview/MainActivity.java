package com.example.pradeepkumar.recyclerview;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.example.pradeepkumar.recyclerview.Adapter.MyAdapter;
import com.example.pradeepkumar.recyclerview.Interface.ILoadMore;
import com.example.pradeepkumar.recyclerview.model.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<Item> Items = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        randomData();
       recyclerView = (RecyclerView) findViewById(R.id.programmingList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(recyclerView, MainActivity.this, Items);
        recyclerView.setAdapter(adapter);
        adapter.setLoadMore(new ILoadMore()

        {
            @Override
            public void onLoadMore() {
                if (Items.size() <= 50) {
                    Items.add(null);
                    adapter.notifyItemInserted(Items.size() - 1);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Items.remove(Items.size() - 1);
                            adapter.notifyItemRemoved(Items.size());
                            int index = Items.size();
                           int end = index + 10;
                            for (int i = index; i < end; i++) {
                                String name = UUID.randomUUID().toString();
                                Item item = new Item(name.length(),name);
                                Items.add(item);
                            }
                            adapter.notifyDataSetChanged();
                            adapter.setLoaded();
                        }
                    }, 2000);
                } else {
                    Toast.makeText(MainActivity.this,"Load data completed !",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
       private void randomData(){

        for(int i=0;i<10;i++){
            String name = UUID.randomUUID().toString();
            Item item = new Item(name.length(),name);
            Items.add(item);
        }
    }
}
