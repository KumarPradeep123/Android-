package com.example.pradeepkumar.recyclerview.Interface;

/**
 * Created by PRADEEP KUMAR on 17-01-2018.
 */

public interface ILoadMore {
    void onLoadMore();
}
