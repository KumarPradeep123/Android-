package com.example.pradeepkumar.recyclerview.Adapter;

import android.app.Activity;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.pradeepkumar.recyclerview.Interface.ILoadMore;
import com.example.pradeepkumar.recyclerview.R;
import com.example.pradeepkumar.recyclerview.model.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PRADEEP KUMAR on 16-01-2018.
 */
class LoadingViewHolder extends RecyclerView.ViewHolder {
    public ProgressBar progressBar;

    public LoadingViewHolder(View itemView) {
        super(itemView);
        progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
    }
}

class ItemViewHolder extends RecyclerView.ViewHolder {
    public TextView roll, name;

    public ItemViewHolder(View itemView) {
        super(itemView);
        roll = (TextView)itemView.findViewById(R.id.textRoll);
        name = (TextView)itemView.findViewById(R.id.textName);
    }
}
   public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
       private final int VIEW_TYPE_ITEM = 0, VIEW_TYPE_LOADING = 1;
       ILoadMore loadMore;
       boolean isLoading;
       Activity activity;
       int visibleThresold = 5;
       int lastVisibleItem, totalItemCount;
       private List<Item> Items;

       public MyAdapter(RecyclerView recyclerView, Activity activity, List<Item> arrayList) {
           this.activity = activity;
           this.Items = Items;

           final LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
           recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener(){
               @Override
               public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                   super.onScrolled(recyclerView, dx, dy);
                   totalItemCount = layoutManager.getItemCount();
                   lastVisibleItem = layoutManager.findLastVisibleItemPosition();
                   if (!isLoading && totalItemCount <= (lastVisibleItem + visibleThresold)) {
                       if (loadMore != null)
                           loadMore.onLoadMore();
                       isLoading = true;
                   }

               }
               });
       }
       @Override
       public int getItemViewType(int position) {
           return Items.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
       }

       public void setLoadMore(ILoadMore loadMore) {
           this.loadMore = loadMore;
       }

       @Override
       public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
           if (viewType == VIEW_TYPE_ITEM) {
               LayoutInflater inflater = LayoutInflater.from(activity);
               View view = inflater.inflate(R.layout.listlayout, parent, false);
               return new ItemViewHolder(view);
           } else if (viewType == VIEW_TYPE_LOADING) {
               LayoutInflater inflater = LayoutInflater.from(activity);
               View view = inflater.inflate(R.layout.progressbar, parent, false);
               return new ItemViewHolder(view);
           }
           return null;
       }

       @Override
       public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
           if (holder instanceof ItemViewHolder) {
               Item item = Items.get(position);
               ItemViewHolder viewHolder = (ItemViewHolder) holder;
               viewHolder.roll.setText("Roll No: " + Items.get(position).getRollNo());
               viewHolder.name.setText("Name: " + Items.get(position).getName());
           } else if(holder instanceof LoadingViewHolder){
               LoadingViewHolder loadingViewHolder = (LoadingViewHolder)holder;
               loadingViewHolder.progressBar.setIndeterminate(true);
           }
       }

       @Override
       public int getItemCount() {
           return Items.size();
       }
       public void setLoaded (){
           isLoading=false;

       }
   }


