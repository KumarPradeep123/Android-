package com.example.lenovo.databasedemo4;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

/**
 * Created by LENOVO on 11/7/2017.
 */

public class DBHelper extends SQLiteOpenHelper {
    Context context;
    public DBHelper(Context context) {
        super(context, "test", null, 1);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //*******************************************************************************************
    public Vector<String> search() {
        Vector<String> vector=new Vector<>();
        try {
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "PersonalInfo", new String[]{"", "age"}, null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                vector.add(cursor.getString(0));
                vector.add(cursor.getString(1));
            }
            return vector;
        } catch (Exception ex) {
            return null;
        }
    }
    //****************************************************************************************
}
