package com.example.lenovo.databasedemo4;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    EditText name, email, age;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            name = (EditText) findViewById(R.id.editText4);
            email = (EditText) findViewById(R.id.editText5);
            age = (EditText) findViewById(R.id.editText6);
            lv = (ListView) findViewById(R.id.lv);
            DBHelper helper=new DBHelper(this);
        try {
            SQLiteDatabase db = helper.getWritableDatabase();
            db.execSQL("create table PersonalInfo(name text primary key, email test, age test)");
            setTitle("Added");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
        Vector<String> vector=helper.search();
        MyAdapter adapter = new MyAdapter(this, vector);
        lv.setAdapter(adapter);
    }

    public void save(View view) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", "" + name.getText());
            values.put("email", "" + email.getText());
            values.put("age", "" + age.getText());
            db.insert("PersonalInfo", null, values);
            setTitle("Saved");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void search(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "PersonalInfo", new String[]{"email", "age"}, "name=?", new String[]{"" + name.getText()}, null, null, null, null);
            if (cursor.moveToFirst()) {
                setTitle("Searched");
                email.setText("" + cursor.getString(0));
                age.setText("" + cursor.getString(1));

                return;
            } else {
                email.setText("Not found");
                age.setText("Not found");
            }
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}