package com.example.pradeepkumar.videorecordingwithaudio;

import java.io.File;

/**
 * Created by PRADEEP KUMAR on 03-12-2017.
 */

abstract class AlbumStorageDirFactory {
    public abstract File getAlbumStorageDir(String albumName);
}
