package com.example.pradeepkumar.netaccessdemo5picdata;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by PRADEEP KUMAR on 08-12-2017.
 */

public class Utilities {
    public static Bitmap getBitmapFromURL(String src) {
        try {

            URL url = new URL(src);

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(60*1000);
            connection.setConnectTimeout(60*1000);
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bmp = BitmapFactory.decodeStream(input);

            return bmp;
        } catch (Exception ex) {
            System.out.println(ex);
            return null;
        }
    }
}

