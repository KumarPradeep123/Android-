package com.example.pradeepkumar.netaccessdemo5picdata;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by PRADEEP KUMAR on 08-12-2017.
 */

public class BookAdapter implements ListAdapter {
    private List<Book> books;
    private LayoutInflater inflater;
    private Context context;

    public BookAdapter(List<Book> books, Context context) {
        this.books = books;
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        this.context = context;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return false;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {
        return books.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View   v=(View)inflater.inflate(R.layout.listlayout,null);
        TextView tvBookName=(TextView)v.findViewById(R.id.tvBookName);
        TextView tvSubject=(TextView)v.findViewById(R.id.tvSubject);
        TextView tvAuthor=(TextView)v.findViewById(R.id.tvAuthor);
        ImageView img=(ImageView) v.findViewById(R.id.img);
        Book book=books.get(position);
        tvBookName.setText(book.getBookname());
        tvAuthor.setText(book.getAuthor());
        tvSubject.setText(book.getSubject());
        if(book.getImage()!=null)
            img.setImageBitmap(book.getImage());
        else {
            ImageDownloader downloader = new ImageDownloader(book.getImageurl(), book, img);
            downloader.execute();
        }
        return v;
    }

    @Override
    public int getItemViewType(int i) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
    //*************************************************
    class ImageDownloader extends AsyncTask
    {
        private String imageurl;
        private Book book;
        private ImageView img;

        public ImageDownloader(String imageurl,Book book,ImageView img) {
            this.imageurl = imageurl;
            this.imageurl=imageurl;
            this.img=img;
        }

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                Bitmap bmp=Utilities.getBitmapFromURL(imageurl);
                return bmp;
            }
            catch (Exception ex)
            {
                return ex;
            }


        }
        @Override
        protected void onPostExecute(Object o) {
            try
            {
                Bitmap bmp=(Bitmap)o;
                img.setImageBitmap(bmp);
                book.setImage(bmp);
            }
            catch (Exception ex)
            {
                System.out.println(ex);
            }
        }
    }

    //**************************************************




}