package com.example.pradeepkumar.netaccessdemo5picdata;

import android.graphics.Bitmap;

/**
 * Created by PRADEEP KUMAR on 08-12-2017.
 */

public class Book {
    private String bookname,subject,author,imageurl;
    Bitmap image;

    public Book(String bookname, String subject, String author,String imageurl) {
        this.bookname = bookname;
        this.subject = subject;
        this.author = author;
        this.imageurl = imageurl;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

    public String getImageurl() {
        return imageurl;
    }

    public String getBookname() {
        return bookname;
    }

    public String getSubject() {
        return subject;
    }

    public String getAuthor() {
        return author;
    }

    public Bitmap getImage() {
        return image;
    }
}
