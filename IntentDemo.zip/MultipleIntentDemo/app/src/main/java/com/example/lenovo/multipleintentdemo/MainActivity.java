package com.example.lenovo.multipleintentdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText txtData;
    final int reqcode=10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtData=(EditText) findViewById(R.id.editText);

    }
    public void next(View view)
    {
        setTitle("Clicked");
        Intent intent=new Intent(this,NextActivity.class);
        intent.putExtra("data","" + txtData.getText());
        startActivityForResult(intent,reqcode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String returndata=data.getStringExtra("data");
        txtData.setText(returndata);
    }
}

