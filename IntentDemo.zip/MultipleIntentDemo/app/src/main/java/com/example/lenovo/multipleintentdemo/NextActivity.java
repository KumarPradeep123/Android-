package com.example.lenovo.multipleintentdemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class NextActivity extends AppCompatActivity {
    EditText txtData2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        txtData2=(EditText) findViewById(R.id.editText2);
        Intent intent=getIntent();
        String data=intent.getStringExtra("data");
        txtData2.setText(data);
        setTitle("Next");
    }
    public void prev(View view)
    {
        setTitle("Clicked");
        Intent intent=new Intent();
        intent.putExtra("data","" + txtData2.getText());
        setResult(RESULT_OK,intent);
        this.finish();
    }
}
