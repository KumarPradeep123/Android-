package in.hypatiasoftwaresolutions.smssender;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
private final int SEND_SMS_PERMISSION=1;
private TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=(TextView)findViewById(R.id.txt);
    }

    public void sendMessage(View view)
    {
        try
        {
            String SENT = "SMS_SENT";
            SmsSentReceiver sentReceiver=new SmsSentReceiver();
            Intent intent=new Intent(SENT);
            PendingIntent sentIntent=PendingIntent.getBroadcast(this,0,intent,0);
            registerReceiver(sentReceiver,new IntentFilter(SENT));
            SmsManager manager=SmsManager.getDefault();
            String mobileno="9335874326";
            String message="Ka Ho Champak?";
            manager.sendTextMessage(mobileno,null,message,sentIntent,null);
            setTitle("Sending Done");
        }
        catch (Exception ex)
        {
            setTitle(ex.getMessage());
        }
    }


    public void getPermission(View view) {
        setTitle("Clicked");
        try
        {
            boolean hasPermission=Utilities.checkPermission(this,Manifest.permission.SEND_SMS);
        if (hasPermission) {

            setTitle("Has SMS Sending Permission");
            return;
        }
boolean requiresMessage=Utilities.checkPermissionRequired(this,Manifest.permission.SEND_SMS);

            // Show an explanation if permission has been denied
            if (requiresMessage) {
            txt.setText("This App needs to send SMS");
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SEND_SMS_PERMISSION);

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SEND_SMS_PERMISSION);


            }


        }
        catch (Exception ex)
        {
            setTitle(ex.getMessage());
        }
    }
        @Override
        public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
            switch (requestCode) {
                case SEND_SMS_PERMISSION: {
                    // If request is cancelled, the result arrays are empty.
                    if (grantResults.length > 0
                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                       setTitle("Permission Given");

                    } else {
                        setTitle("Permission Not Given");

                                           }
                    return;
                }

            }
        }
}
