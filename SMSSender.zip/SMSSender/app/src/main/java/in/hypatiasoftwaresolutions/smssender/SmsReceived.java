package in.hypatiasoftwaresolutions.smssender;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Champak Roy on 11/14/2017.
 */

public class SmsReceived extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Utilities.showToast(context,"SMS Received");
    }
}
