package in.hypatiasoftwaresolutions.smssender;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;


public class SmsSentReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int resultCode = getResultCode();
        switch (resultCode) {
            case Activity.RESULT_OK:
                Utilities.showToast(context, "SMS sent");
                break;
            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                Utilities.showToast(context, "Generic Failure");

                break;
            case SmsManager.RESULT_ERROR_NO_SERVICE:
                Utilities.showToast(context, "No service");

                break;
            case SmsManager.RESULT_ERROR_NULL_PDU:
                Utilities.showToast(context, "Null PDU");

                break;
            case SmsManager.RESULT_ERROR_RADIO_OFF:
                Utilities.showToast(context, "Radio off");

                break;
                default:
                    Utilities.showToast(context, "Unspecified error");
        }

    }
}
