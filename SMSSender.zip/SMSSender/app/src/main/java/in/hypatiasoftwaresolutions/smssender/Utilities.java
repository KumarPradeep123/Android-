package in.hypatiasoftwaresolutions.smssender;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class Utilities {
    public static boolean showToast(Context context,String message)
    {
        try
        {


            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, message, duration);
            toast.show();
            return true;
        }
        catch (Exception ex)
        {
            System.out.println(ex);
            return false;
        }
    }
    public static boolean checkPermission(Context context,String permission)
    {
      int result=  ContextCompat.checkSelfPermission(context,permission);
             if(result   == PackageManager.PERMISSION_GRANTED)
                 return true;
             return false;
    }
    public static boolean checkPermissionRequired(AppCompatActivity activity,String permission)
    {
       boolean b= ActivityCompat.shouldShowRequestPermissionRationale(activity,permission);
       return b;
    }
}
