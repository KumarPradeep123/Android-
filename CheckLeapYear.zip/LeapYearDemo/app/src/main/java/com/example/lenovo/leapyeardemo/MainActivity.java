package com.example.lenovo.leapyeardemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText) findViewById(R.id.editText);
        e2=(EditText) findViewById(R.id.editText2);
    }
    public void go (View View)
    {
        int n = Integer.parseInt("" + e1.getText());
        if((n%400==0) || ((n%4==0) && (n%100!=0)))
            e2.setText("Year" + " " + n + " " + "is a leap year");
        else
            e2.setText("Year" + " " + n + " " + "is not a leap year");

    }
}