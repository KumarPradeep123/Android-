package com.example.pradeepkumar.videocamerademo;

import android.content.Context;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.widget.Toast;

/**
 * Created by PRADEEP KUMAR on 02-12-2017.
 */

public class RecorderSurface  implements SurfaceHolder.Callback {

    private Camera camera;
    private Context context;
    public RecorderSurface(Camera camera, Context context)
    {
        this.camera=camera;
        this.context=context;
    }
    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (camera != null) {
            Camera.Parameters params = camera.getParameters();
            camera.setParameters(params);
            Toast.makeText(context, "Surface Created", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(context, "Camera is not available",
                    Toast.LENGTH_LONG).show();


        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
    }
}

