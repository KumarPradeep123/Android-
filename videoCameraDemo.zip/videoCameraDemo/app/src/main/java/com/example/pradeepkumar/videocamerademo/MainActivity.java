package com.example.pradeepkumar.videocamerademo;

import android.content.pm.ActivityInfo;
import android.hardware.Camera;
import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import java.io.File;
import java.io.IOException;
import java.util.Date;

public class MainActivity extends AppCompatActivity
{
    private SurfaceHolder sh;
    private SurfaceView sv;
    public MediaRecorder mrec = new MediaRecorder();
    private Camera camera;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);
        try {
            button=(Button) findViewById(R.id.button);
            sv = (SurfaceView) findViewById(R.id.surfaceView);
            camera = Camera.open();
            setTitle("Start");

            sh = sv.getHolder();
            sh.addCallback(new RecorderSurface(camera,this));
            sh.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        }
        catch (Exception ex)
        {
            System.out.println(ex);
            setTitle(ex.getMessage());
        }
    }



    public void TakeVideo(View view)
    {
        if(button.getText().equals("Start"))
        {
            try  {

                startRecording();
                button.setText("Stop");

            } catch (Exception e) {

                String message = e.getMessage();
                setTitle("Problem " + message);
                mrec.release();
            }

        }
        else if(button.getText().equals("Stop"))
        {
            mrec.stop();
            mrec.release();
            mrec = null;
            button.setText ("Start");
        }


    }

    protected void startRecording() throws IOException
    {
        if(camera==null)
            camera = Camera.open();

        String filename;
        String path;

        path= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath().toString();

        Date date=new Date();
        filename="/pappu"+date.toString().replace(" ", "_").replace(":", "_")+".mp4";

        //create empty file it must use
        File file=new File(path,filename);

        mrec = new MediaRecorder();

        camera.lock();
        camera.unlock();
        // mCamera.setDisplayOrientation(90); // use for set the orientation of the preview
        mrec.setOrientationHint(90);
        mrec.setCamera(camera);
        mrec.setVideoSource(MediaRecorder.VideoSource.CAMERA);
        mrec.setAudioSource(MediaRecorder.AudioSource.MIC);
        mrec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mrec.setVideoEncoder(MediaRecorder.VideoEncoder.MPEG_4_SP);
        mrec.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mrec.setPreviewDisplay(sh.getSurface());
        mrec.setOutputFile(path+filename);
        mrec.prepare();
        mrec.start();


    }

    protected void stopRecording() {

        if(mrec!=null)
        {
            mrec.stop();
            mrec.release();
            camera.release();
            camera.lock();
        }
    }

    private void releaseMediaRecorder() {

        if (mrec != null) {
            mrec.reset(); // clear recorder configuration
            mrec.release(); // release the recorder object
        }
    }

    private void releaseCamera() {
        if (camera != null) {
            camera.release(); // release the camera for other applications
            camera = null;
        }

    }
}
