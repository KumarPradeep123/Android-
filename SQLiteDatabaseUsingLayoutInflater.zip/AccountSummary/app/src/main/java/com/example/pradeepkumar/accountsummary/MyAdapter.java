package com.example.pradeepkumar.accountsummary;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by PRADEEP KUMAR on 04-01-2018.
 */

public class MyAdapter implements ListAdapter {
    private LayoutInflater inflater;
    private Context context;
    private List<AccountData> data;
    public MyAdapter(Context context, List<AccountData> data){
        this.context=context;
        this.data=data;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return false;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {return data.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View rowView = inflater.inflate(R.layout.layout, null);
        TextView myAmount=(TextView)rowView.findViewById(R.id.pAmnt);
        TextView myName=(TextView) rowView.findViewById(R.id.pName);
        TextView myNumber=(TextView) rowView.findViewById(R.id.pNumber);
        TextView myDate=(TextView)rowView.findViewById(R.id.pDate);
        AccountData accountData=data.get(i);
        myName.setText(accountData.getSrno() + "-  " + accountData.getName());
        myNumber.setText("Account Number:  " + accountData.getNumber());
        myAmount.setText(accountData.getAmount()+ " Rs/- " + " From " + accountData.getOther());
         myDate.setText(accountData.getDay() + "/" + accountData.getMonth() + "/" + accountData.getYear());
        return rowView;
    }

    @Override
    public int getItemViewType(int i) {
        return 1;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}
