package com.example.pradeepkumar.accountsummary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PRADEEP KUMAR on 05-01-2018.
 */

public class Utilities {
    public static List<AccountData> getAllData(Context context) {
        List<AccountData> lst = new ArrayList<>();
        try {

            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "account", new String[]{"srno","number","name","amount","other","day","month", "year"}, null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                String srno = cursor.getString(0);
                String number = cursor.getString(1);
                String name = cursor.getString(2);
                String amount = cursor.getString(3);
                String other = cursor.getString(4);
                String day = cursor.getString(5);
                String month = cursor.getString(6);
                String year = cursor.getString(7);

                AccountData accountData = new AccountData(srno,number,name,amount,other, day, month, year);
                lst.add(accountData);

            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return lst;
    }

}


