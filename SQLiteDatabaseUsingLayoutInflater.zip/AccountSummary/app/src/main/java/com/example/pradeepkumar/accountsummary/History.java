package com.example.pradeepkumar.accountsummary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.List;

public class History extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        lv=(ListView)findViewById(R.id.list);
        List<AccountData> vector = Utilities.getAllData(this);
        MyAdapter adapter = new MyAdapter(this, vector);
        lv.setAdapter(adapter);
    }
}
