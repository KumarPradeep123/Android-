package com.example.lenovo.pesonalreminderpractice;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

/**
 * Created by LENOVO on 11/10/2017.
 */

public class Utilities {
    public static void SendNotification(String message, Context context){
        NotificationManager notificationManager=(NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);
        int notifyId=1;
        NotificationCompat.Builder nBuilder=new NotificationCompat.Builder(context);
        nBuilder.setContentTitle("Receive Notification");
        nBuilder.setContentText(message);
        nBuilder.setVibrate(new long[]{1,222,3,700});
        Uri soundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        nBuilder.setSound(soundUri);
        nBuilder.setSmallIcon(Notification.BADGE_ICON_SMALL);
        notificationManager.notify(notifyId, nBuilder.build());
    }
}
