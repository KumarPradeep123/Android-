package com.example.lenovo.pesonalreminderpractice;

import android.content.ContentValues;
import android.content.Context;
import android.database.DataSetObserver;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.Vector;

/**
 * Created by LENOVO on 11/9/2017.
 */

public class MyAdapter implements ListAdapter {


    //******************************Button Click*******************************

    class UpdateHandler implements View.OnClickListener {
        DataClass dc;
        TextView txtId;
        TextView txtdctn;

        public UpdateHandler(DataClass dc, TextView txtId, TextView txtdctn) {
            this.dc = dc;
            this.txtId = txtId;
            this.txtdctn = txtdctn;
        }

        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            try {
                DBHelper helper = new DBHelper(context);
                SQLiteDatabase db = helper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("id", "" + txtId.getText());
                values.put("descreption", "" + txtdctn.getText());
                int n = db.update("Reminder", values, "label=?", new String[]{"" + dc.getId()});
                if (n >= 0)
                    b.setText("Updated " + n);
                else
                    b.setText("Not updated " + n);
            } catch (Exception ex) {
                b.setText(ex.getMessage());
            }
        }
    }


    //******************************Button Click*******************************
//******************************Button Click*******************************

    class SendHandler implements View.OnClickListener {
        DataClass dc;
        TextView txtId;
        TextView txtdctn;

        public SendHandler(DataClass dc, TextView txtId, TextView txtdctn) {
            this.dc = dc;
            this.txtId = txtId;
            this.txtdctn = txtdctn;
        }

        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            b.setText("Clicked");

            try {
                Utilities.SendNotification(dc.getDscptn()+ dc.getLevel()+ dc.getId(), context);
            } catch (Exception ex) {
                b.setText(ex.getMessage());
            }
        }
    }


    //******************************Button Click*******************************


    //******************************Button Click*******************************

    class DeleteHandler implements View.OnClickListener {
        DataClass dc;
        TextView txtId;
        TextView txtdctn;

        public DeleteHandler(DataClass dc, TextView txtId, TextView txtdctn) {
            this.dc = dc;
            this.txtId = txtId;
            this.txtdctn = txtdctn;
        }

        @Override
        public void onClick(View view) {
            Button b = (Button) view;
            b.setText("Clicked");

            try {
                DBHelper helper = new DBHelper(context);
                SQLiteDatabase db = helper.getWritableDatabase();
                int n = db.delete("Reminder", "label=?", new String[]{"" + dc.getId()});
                if (n >= 0)
                    b.setText("Deleted " + n);
                else
                    b.setText("Not Deleted " + n);
            } catch (Exception ex) {
                b.setText(ex.getMessage());
            }
        }
    }


    //******************************Button Click*******************************

    private LayoutInflater inflater;
    private Context context;
    Vector<DataClass> vector;

    public MyAdapter(Context context, Vector<DataClass> vector) {
        this.context = context;
        this.vector = vector;
        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return true;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }

    @Override
    public int getCount() {
        return vector.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View rowView = inflater.inflate(R.layout.listlayout, null);
        EditText txtid = (EditText) rowView.findViewById(R.id.editText4);
        EditText txtlabel = (EditText) rowView.findViewById(R.id.editText5);
        EditText txtdctn = (EditText) rowView.findViewById(R.id.editText6);
        Button button1 = (Button) rowView.findViewById(R.id.bttnUpdate);
        Button button2 = (Button) rowView.findViewById(R.id.bttnDelete);
        Button button3 = (Button) rowView.findViewById(R.id.bttnSend);
        DataClass dc = vector.get(i);
        txtid.setText("" + dc.getId());
        txtlabel.setText(dc.getLevel());
        txtdctn.setText(dc.getDscptn());
        button1.setText("Update");
        button2.setText("Delete");
        button3.setText("Send");
        UpdateHandler handler1 = new UpdateHandler(dc, txtid, txtdctn);
        DeleteHandler handler2 = new DeleteHandler(dc, txtid, txtdctn);
        SendHandler handler3 = new SendHandler(dc, txtid, txtdctn);
        button1.setOnClickListener(handler1);
        button2.setOnClickListener(handler2);
        button3.setOnClickListener(handler3);
        return rowView;
    }

    @Override
    public int getItemViewType(int i) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }
}