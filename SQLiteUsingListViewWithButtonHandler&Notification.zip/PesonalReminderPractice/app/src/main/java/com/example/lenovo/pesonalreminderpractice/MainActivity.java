package com.example.lenovo.pesonalreminderpractice;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText txtNo, txtLbl, txtDtn;
    int reqcode=10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtNo=(EditText) findViewById(R.id.editText);
        txtLbl=(EditText) findViewById(R.id.editText2);
        txtDtn=(EditText) findViewById(R.id.editText3);
    }
    public void next(View view){
        Utilities.SendNotification("" + txtLbl.getText(), this);
        Intent intent = new Intent(this, NextActivity.class);
        intent.putExtra("Label",txtLbl.getText().toString());
        startActivityForResult(intent, reqcode);

    }
    public void create(View view){
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            String query = "create table Reminder(id number primary key,label text, descreption text)";
            db.execSQL(query);
            setTitle("Created");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
    public void save(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("id", "" + txtNo.getText());
            values.put("label", "" + txtLbl.getText());
            values.put("descreption", "" + txtDtn.getText());
            db.insert("Reminder", null, values);
            setTitle("Saved");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
    public void search(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "Reminder", new String[]{"id", "descreption"}, "label=?", new String[]{"" + txtLbl.getText()}, null, null, null, null);
            if (cursor.moveToFirst()) {
                setTitle("Searched");
                txtNo.setText("" + cursor.getString(0));
                txtDtn.setText("" + cursor.getString(1));
                return;
            } else {
                txtNo.setText("Not found");
                txtDtn.setText("Not found");
            }
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}