package com.example.pradeepkumar.downloadmanagerusingalarm;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotifyAlarmReceiver alarm = new NotifyAlarmReceiver();
        alarm.setAlarm(this);
    }

    public void StartDownload(View view) {
        long downloadnumber = 0;
        try {
            final DownloadManager manager;
            manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            BroadcastReceiver receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                        long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                        DownloadManager.Query query = new DownloadManager.Query();
                        query.setFilterById(downloadId);
                        Cursor cursor = manager.query(query);
                        if (cursor.moveToFirst()) {

                            int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                            int status = cursor.getInt(columnIndex);

                            int columnReason = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                            int reason = cursor.getInt(columnReason);

                            int filenameIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME);
                            String filename = cursor.getString(filenameIndex);

                            int downloadResult = cursor.getInt(columnIndex);
                            if (downloadResult != DownloadManager.STATUS_SUCCESSFUL) {
                                setTitle("Downloading failed");
                                return;
                            }


                            String downloadedFileUri = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                            setTitle("Download complete \n" + filename);

                        }
                    }
                }

            };

            registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse("https://i1.wp.com/blogs.hypatiasoftwaresolutions.in/wp-content/uploads/2017/10/p1.jpg"));
            downloadnumber = manager.enqueue(request);
        } catch (Exception ex) {
            System.out.println(ex);
            setTitle(ex.getMessage());
        }
    }

    public void setAlarm(View view) {
        try {
            setTitle("ALarm");
            Utilities.SendNotification("Alarm", this);

        } catch (Exception ex) {
            System.out.println(ex);
            setTitle(ex.getMessage());
        }
    }

}