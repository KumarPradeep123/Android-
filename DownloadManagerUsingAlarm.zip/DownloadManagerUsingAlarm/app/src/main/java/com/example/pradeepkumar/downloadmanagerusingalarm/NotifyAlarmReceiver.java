package com.example.pradeepkumar.downloadmanagerusingalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.WakefulBroadcastReceiver;

/**
 * Created by LENOVO on 11/22/2017.
 */

public class NotifyAlarmReceiver extends WakefulBroadcastReceiver {
    private AlarmManager alarmmgr;
    private PendingIntent alarmIntent;
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service = new Intent(context , NotifySchedulingService.class);
        startWakefulService(context,service);
    }
    public void setAlarm(Context context)
    {

        alarmmgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context , NotifyAlarmReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(context,0,intent,0);

        alarmmgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME,60000, 60000, alarmIntent);
        // alarmmgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME,AlarmManager.INTERVAL_HALF_HOUR, AlarmManager.INTERVAL_FIFTEEN_MINUTES, alarmIntent);
        ComponentName receiver = new ComponentName(context , NotifyBootReceiver.class);
        PackageManager pm = context.getPackageManager();

        pm.setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_DEFAULT, PackageManager.DONT_KILL_APP);
    }
    public void cancelAlarm(Context context)
    {
        if(alarmmgr!=null)
        {
            alarmmgr.cancel(alarmIntent);
        }
        ComponentName receiver = new ComponentName(context, NotifyBootReceiver.class);
        PackageManager pm = context.getPackageManager();

        pm.setComponentEnabledSetting(receiver,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }


}

