package com.example.pradeepkumar.downloadmanagerusingalarm;

import android.app.DownloadManager;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;

/**
 * Created by LENOVO on 11/22/2017.
 */

public class NotifySchedulingService extends IntentService {
    DownloadManager manager;
    long downloadNumber;

    public NotifySchedulingService() {super("SchedulingService");

  /*  //**************************************************

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(downloadId);
                Cursor cursor = manager.query(query);
                if (cursor.moveToFirst()) {

                    int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                    int status = cursor.getInt(columnIndex);

                    int columnReason = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                    int reason = cursor.getInt(columnReason);


                    int downloadResult = cursor.getInt(columnIndex);
                    if (downloadResult != DownloadManager.STATUS_SUCCESSFUL) {
                        Utilities.SendNotification("Downloading failed",context);
                        return;
                    }


                    String downloadedFileUri = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));


                }
            }
        }

    };

    registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

    //**************************************************

*/

    }
    @Override
    protected void onHandleIntent(Intent intent) {
        Context context = getApplicationContext();
        try
        {

            //manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
           // DownloadManager.Request request = new DownloadManager.Request(Uri.parse("https://i1.wp.com/blogs.hypatiasoftwaresolutions.in/wp-content/uploads/2017/10/p1.jpg"));
            //downloadNumber = manager.enqueue(request);
            Utilities.SendNotification("Alarm Chal gaya", context);

        }
        catch (Exception ex)
        {
            System.out.println(ex);
            Utilities.SendNotification("" + ex, context);
        }
        NotifyAlarmReceiver.completeWakefulIntent(intent);
    }
}