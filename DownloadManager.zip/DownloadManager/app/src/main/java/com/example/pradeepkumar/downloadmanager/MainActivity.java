package com.example.pradeepkumar.downloadmanager;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private EditText txtUrl, txtDetails;
    private ImageView img;
    private DownloadManager manager;
    private long downloadnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtDetails = (EditText) findViewById(R.id.txtDetails);
        txtDetails.setEnabled(false);
        txtUrl = (EditText) findViewById(R.id.txtURL);
        img = (ImageView) findViewById(R.id.img);

        //**************************************************

        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
                    long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0);
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(downloadId);
                    Cursor cursor = manager.query(query);
                    if (cursor.moveToFirst()) {

                        int columnIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        int status = cursor.getInt(columnIndex);

                        int columnReason = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                        int reason = cursor.getInt(columnReason);

                        int filenameIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_FILENAME);
                        String filename = cursor.getString(filenameIndex);


                        int downloadresult=cursor.getInt(columnIndex);
                        if (downloadresult!= DownloadManager.STATUS_SUCCESSFUL)
                        {
                            txtDetails.setText("Downloading failed");
                            return;
                        }


                        String downloadedfileuri = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                        img.setImageURI(Uri.parse(downloadedfileuri));
                        txtDetails.setText("Download complete \n" + filename);
                    }
                }
            }

        };

        registerReceiver(receiver, new IntentFilter(
                DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        //**************************************************
    }

    public void createDownload(View view) {
        try {
            manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse("" + txtUrl.getText()));
            downloadnumber = manager.enqueue(request);
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void doDownload(View view) {
        try {
            Intent i = new Intent();
            i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
            startActivity(i);
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}