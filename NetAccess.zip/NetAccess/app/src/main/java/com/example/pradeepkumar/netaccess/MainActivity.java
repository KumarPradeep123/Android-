package com.example.pradeepkumar.netaccess;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private TextView txtDownload;
    EditText txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtDownload=(TextView)findViewById(R.id.txtDownloaded);
        txt=(EditText)findViewById(R.id.editText);
    }
    public void doDownload(View view)
    {
        setTitle("Downloading");
        Downloader downloader=new Downloader();
        downloader.execute();
    }

    //***********************************************

    class Downloader extends AsyncTask
    {

        @Override
        protected Object doInBackground(Object[] objects) {
            try
            {
                //URL url=new URL("http://" + txt.getText());
                URL url=new URL("http://pradeep.softwareforyou.in/data.html");
                URLConnection connection= url.openConnection();
                Scanner scanner=new Scanner(connection.getInputStream());
                String str="";
                while (scanner.hasNextLine())
                    str=str + scanner.nextLine() + "\n";
                return str;
            }
            catch (Exception ex)
            {
                return ex;
            }


        }
        @Override
        protected void onPostExecute(Object o)
        {
            try
            {
                if(o instanceof Exception)
                    throw (Exception)o;
                JSONObject jsonObject=new JSONObject("" + o);
                JSONArray jsonArray=jsonObject.getJSONArray("books");
                int length=jsonArray.length();

                txtDownload.setText("" + length);
            }
            catch (Exception ex)
            {
                txtDownload.setText(ex.getMessage());
            }
        }
    }

    //************************************************
}
