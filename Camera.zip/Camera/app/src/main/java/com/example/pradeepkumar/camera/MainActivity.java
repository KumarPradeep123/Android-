package com.example.pradeepkumar.camera;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQEST=1888;
    private final int CAMERA_PERMISSION=1;
    private ImageView img;
    private Uri uri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img=(ImageView)findViewById(R.id.img);
        // for permission
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                // Show an explanation if permission has been
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
                } else {
                    // No explanation needed, we can request the permission.
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
                }
            }
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        switch (requestCode) {
            case CAMERA_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    setTitle("Permission Given");
                } else {
                    setTitle("Permission Not Given");
                    return;
                }
            }
        }
    }
    //***************************************************************
    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        try
        {
            boolean debug=false;
            if(requestCode!=CAMERA_REQEST)
                return;
            if(data==null)
                return;
            if(data.hasExtra("data"))
            {
                Bitmap thumbnail=data.getParcelableExtra("data");
                img.setImageBitmap(thumbnail);
                return;
            }

            int width=300;//img.getWidth();
            int height=300;//img.getHeight();
            setTitle(width + "," + height);
            if(debug)
                return;
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inJustDecodeBounds=true;
            BitmapFactory.decodeFile(uri.getPath(),options);
            int imgWidth=options.outWidth;
            int imgHeight=options.outHeight;
            if(width<=0)
                width=1;
            if(height<=0)
                height=1;
            int scaleFactor=Math.min(imgWidth/width,imgHeight/height);
            options.inJustDecodeBounds=false;
            options.inSampleSize=scaleFactor;
            options.inPurgeable=true;
            Bitmap bitmap=BitmapFactory.decodeFile(uri.getPath(),options);
            img.setImageBitmap(bitmap);

        }
        catch (Exception ex)
        {
            System.out.println(ex);

        }
    }
    //***************************************************************
    public void camera(View view)
    {
        try
        {
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,CAMERA_REQEST);
            File pictureDirectory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            String pictureName=getPictureName();
            File imagefile=new File(pictureDirectory, pictureName);
            Uri pictureUri=Uri.fromFile(imagefile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,pictureUri);

        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }
    }
    private String getPictureName(){
        SimpleDateFormat sdf= new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp= sdf.format(new Date());
        return "Plane place image" + timestamp +".jpg";
    }
}
