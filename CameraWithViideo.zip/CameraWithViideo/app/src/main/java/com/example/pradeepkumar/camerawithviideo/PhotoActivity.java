package com.example.pradeepkumar.camerawithviideo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PhotoActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST=1888;
    private ImageView img;
    private Uri uri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        img=(ImageView)findViewById(R.id.img);
    }
    //***************************************************************
    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        try
        {
            boolean debug=false;
            if(requestCode!=CAMERA_REQUEST)
                return;
            if(data==null)
                return;
            if(data.hasExtra("data"))
            {
                Bitmap thumbnail=data.getParcelableExtra("data");
                img.setImageBitmap(thumbnail);
                return;
            }

            int width=300;//img.getWidth();
            int height=300;//img.getHeight();
            setTitle(width + "," + height);
            if(debug)
                return;
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inJustDecodeBounds=true;
            BitmapFactory.decodeFile(uri.getPath(),options);
            int imgWidth=options.outWidth;
            int imgHeight=options.outHeight;
            if(width<=0)
                width=1;
            if(height<=0)
                height=1;
            int scaleFactor=Math.min(imgWidth/width,imgHeight/height);
            options.inJustDecodeBounds=false;
            options.inSampleSize=scaleFactor;
            options.inPurgeable=true;
            Bitmap bitmap=BitmapFactory.decodeFile(uri.getPath(),options);
            img.setImageBitmap(bitmap);

        }
        catch (Exception ex)
        {
            System.out.println(ex);

        }
    }
    //***************************************************************
    public void camera(View view)
    {
        try
        {
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent,CAMERA_REQUEST);
            File pictureDirectory= Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            String pictureName=getPictureName();
            File imagefile=new File(pictureDirectory, pictureName);
            Uri pictureUri=Uri.fromFile(imagefile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,pictureUri);

        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }
    }
    private String getPictureName(){
        SimpleDateFormat sdf= new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp= sdf.format(new Date());
        return "Plane place image" + timestamp +".jpg";
    }
}
