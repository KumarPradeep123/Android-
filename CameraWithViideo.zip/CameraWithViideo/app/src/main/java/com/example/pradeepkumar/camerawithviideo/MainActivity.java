package com.example.pradeepkumar.camerawithviideo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    final int reqcode = 10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void takephoto(View view){
        Intent intentPhoto=new Intent(this, PhotoActivity.class);
        startActivityForResult(intentPhoto,reqcode);
    }

    public void makevideo(View view){
        Intent intentVideo=new Intent(this, VideoActivity.class);
        startActivityForResult(intentVideo,reqcode);
    }

}
