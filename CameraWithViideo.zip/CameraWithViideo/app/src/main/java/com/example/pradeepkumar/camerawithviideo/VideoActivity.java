package com.example.pradeepkumar.camerawithviideo;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.VideoView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VideoActivity extends AppCompatActivity {
    private static final int RECORD_VIDEO = 0;
    private VideoView vr;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video );
        vr = (VideoView) findViewById(R.id.videoView);
    }

    public void video(View view) {
        try {
            Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
            startActivityForResult(intent, RECORD_VIDEO);
            File videoDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
            String videoName = getvideoName();
            File videofile = new File(videoDirectory, videoName);
            Uri videoUri = Uri.fromFile(videofile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);

        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    private String getvideoName() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = sdf.format(new Date());
        return "Plane place image" + timestamp + ".jpg";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == RECORD_VIDEO)
                vr.setVideoURI(data.getData());
            vr.start();

        } catch (Exception ex) {
            System.out.println(ex);

        }
    }
}
