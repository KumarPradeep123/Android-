package com.example.lenovo.personalreminder;

/**
 * Created by LENOVO on 11/8/2017.
 */

public class DataClass
{
    private    int id;
    private   String label, dscptn;

    public DataClass(Object id,Object label,Object dscptn) {
        this.id =Integer.parseInt("" + id);
        this.label="" + label;
        this.dscptn="" + dscptn;
    }

    @Override
    public String toString() {
        return "DataClass{" +
                "id=" + id +
                ", level=" + label +
                ", dscptn='" + dscptn + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getLevel() {
        return label;
    }

    public String getDscptn() {
        return dscptn;
    }
}

