package com.example.lenovo.personalreminder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;

import java.util.Vector;

public class NextActivity extends AppCompatActivity {
    EditText textId, textlabel, textDptn;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
        try {
            String label = getIntent().getExtras().getString("Label");

            textId=(EditText) findViewById(R.id.editText4);
            textlabel=(EditText) findViewById(R.id.editText5);
            textDptn=(EditText) findViewById(R.id.editText6);
            lv = (ListView) findViewById(R.id.lvv);
            DBHelper helper=new DBHelper(this);
            Vector<DataClass> vector=helper.search(label);
            MyAdapter adapter = new MyAdapter(this,vector);
            lv.setAdapter(adapter);
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

}


