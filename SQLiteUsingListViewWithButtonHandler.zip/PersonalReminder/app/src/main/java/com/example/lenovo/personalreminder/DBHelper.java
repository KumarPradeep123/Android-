package com.example.lenovo.personalreminder;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Vector;

/**
 * Created by LENOVO on 11/8/2017.
 */

public class DBHelper extends SQLiteOpenHelper {
    Context context;

    public DBHelper(Context context) {
        super(context, "test", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)  {

    }

    //*******************************************************************************************
    public Vector<DataClass> search(String label) {
        Vector<DataClass> vector = new Vector<>();
        try {
            DBHelper helper = new DBHelper(context);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "Reminder", new String[]{"id", "label", "descreption"}, "label=?", new String[]{"" + label}, null, null, null, null);
            while (cursor.moveToNext()) {
                vector.add(new DataClass(cursor.getString(0), cursor.getString(1), cursor.getString(2)));
            }
            return vector;
        } catch (Exception ex) {
            vector.add(new DataClass(-1, ex.getMessage(),-1));
            return vector;
        }
    }
}