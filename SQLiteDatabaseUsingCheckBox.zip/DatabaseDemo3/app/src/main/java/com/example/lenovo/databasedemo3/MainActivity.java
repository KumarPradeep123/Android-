package com.example.lenovo.databasedemo3;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
    private EditText username, name;
    private RadioButton rdPlane, rdTrain, rdBus;
    private CheckBox chkFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.txtUserName);
        name = (EditText) findViewById(R.id.txtPersonName);
        rdPlane = (RadioButton) findViewById(R.id.rdPlane);
        rdTrain = (RadioButton) findViewById(R.id.rdTrain);
        rdBus = (RadioButton) findViewById(R.id.rdBus);
        chkFood = (CheckBox) findViewById(R.id.chkFood);

        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase  db = helper.getWritableDatabase();
            String query = "create table journeyTickets(username text, name text,transport text, food text)";
            db.execSQL(query);
            setTitle("Created");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void insert(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues   values = new ContentValues();
            String transport="";
            String food="No";
            if(chkFood.isChecked())
                food="Yes";
            if(rdBus.isChecked())
                transport="Bus";
            if(rdPlane.isChecked())
                transport="Plane";
            if(rdTrain.isChecked())
                transport="Train";
            if(transport.equals("")) {
                setTitle("Please select a transport");
                return;
            }
            values.put("username", "" + username.getText());
            values.put("name", "" + name.getText());
            values.put("transport", "" + transport);
            values.put("food", "" + food);
            db.insert("journeyTickets", null, values);
            setTitle("Inserted");
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }

    public void select(View View) {
        try {
            DBHelper helper = new DBHelper(this);
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor cursor = db.query(false, "journeyTickets", new String[]{"name", "transport", "food"}, "username=?", new String[]{"" + username.getText()}, null, null, null, null);
            if (cursor.moveToFirst()) {
                setTitle("Selected");
                name.setText("" + cursor.getString(0));
                String transport=cursor.getString(1);
                String food=cursor.getString(2);
                if(transport.equals(("Bus")))
                    rdBus.setChecked(true);
                if(transport.equals(("Train")))
                    rdTrain.setChecked(true);
                if(transport.equals(("Plane")))
                    rdPlane.setChecked(true);
                if(food.equals("Yes"))
                    chkFood.setChecked(true);
                else
                    chkFood.setChecked(false);

                return;
            } else {
                name.setText("Not found");
            }
        } catch (Exception ex) {
            setTitle(ex.getMessage());
        }
    }
}